number = 0
while True :
    count = input("Enter number : ")
    if count == "No" : 
        break
    else : 
        count = int(count)
        number+=count

print(number)
