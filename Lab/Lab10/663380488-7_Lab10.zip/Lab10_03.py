text = "Information Technology Program, College of computing"
letter = {}
listNumber = []
listLetter = []
for i in text :
    if i.isalpha() :
        i = i.upper()
        if i not in letter :
            letter[i] = 1
        else : 
            letter[i] += 1


result = {k:v for k,v in sorted(letter.items(),key=lambda item : item[1],reverse=True)}


for k,v in result.items():
    print(k,":",v)
    
