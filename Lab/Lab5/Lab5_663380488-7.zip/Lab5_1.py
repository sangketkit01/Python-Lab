number = int(input("Enter number :"))
if number %2 == 0 :
    print(number,"is odd number")
else : print(number,"is even number")