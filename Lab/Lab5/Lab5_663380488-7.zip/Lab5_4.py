age = int(input("Enter age :"))
if 0 <= age <= 12 :
    print("My age is",age)
    print("My range of age : kid")

elif 13 <= age <= 29 :
    print("My age is",age)
    print("My range of age : teen")

elif 30 <= age <=59 :
    print("My age is",age)
    print("My range of age : adult")

else :
    print("My age is",age)
    print("My range of age : old")