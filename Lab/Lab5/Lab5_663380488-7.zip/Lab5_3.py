x = int(input("Enter number : "))
if x>0 :
    print(x,"is positive")
else : print(x,"is negative")