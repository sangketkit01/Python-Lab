subject = {}
for i in range(5) :
     a = input("Enter score : ")
     subject[a] = float(input("Enter score : "))

print("คะแนนสูงสุด : {} | วิชา : {}".format(max(subject.values()),min(subject)))
print("คะแนนต่ำสุด : {} | วิชา : {}".format(min(subject.values()),max(subject)))





            
        
    
    




