sublist = []
print("""=====ฟังก์ชั่นการทำงาน=====
a : เพิ่มรายวิชา
d : ลบรายวิชา
p : พิมพ์รายวิชา
y : จบการทำงาน""")
while True :
    opt = input("ฟังก์ชั่นการทำงาน : ")
    if opt == 'a' :
        addsub = input("กรอกวิชาที่ต้องการเพิ่ม : ")
        sublist.append(addsub)
    elif opt == 'd' :
        removesub = input("กรอกวิชาที่ต้องการลบ : ")
        sublist.remove(removesub)
    elif opt == 'p' :
        print("วิชาทั้งหมด :",sublist)
    elif opt == 'y' :
        print("จบการทำงาน")
        break