sentence01 = "blue-green-red-red-blue-yellow-black-white-blue-red-green-black-black-blue"

def findColor(color) :
    colorList = color.split("-")
    newSentence = "-".join(sorted(colorList))
    colorDict = {}
    for i in colorList :
        if i not in colorDict :
            colorDict[i] = 1
        else :
            colorDict[i] += 1
    return {k:v for k,v in sorted(colorDict.items(),key=lambda item : item[0])},newSentence

colorNumber,sentence02 = findColor(sentence01)
print("""New sentence = {}
The number of each number is '{}'""".format(sentence02,colorNumber))